#!/usr/bin/env python
# -*- coding: utf-8 -*-
import traceback
import zipfile, os, sys, gc
sys.path.append('../../../Chu')
if sys.getdefaultencoding() != 'utf-8':
    print('set default encoding')
    reload(sys)
    sys.setdefaultencoding('utf-8')

import numpy as np
# from thulac import thulac
import jieba.posseg as pseg
from case.words import label_1000
from keras.utils import np_utils
from case.words.word_model import WordModel

label_dict = {}

def convert_label(label):
    label_dict.get(label, None)


class WordToVector(object):
    def __init__(self, model, save_path, cut_tool='jieba'):
        self.model = model
        self.cut_tool = cut_tool
        self.save_path = save_path

    def to_vec(self, data, sentence_size=100):
        data = list(data)
        data_size = len(data)
        results = np.zeros(shape=(data_size, sentence_size, self.model.vector_size))
        for i in range(data_size):
            counter = 0
            for j in range(len(data[i])):
                if data[i][j] in self.model:
                    results[i][counter] = self.model[data[i][j]]
                    counter += 1
                if counter == sentence_size:
                    break
        np.save('vec.npy', results)

    def to_vector_from_zipfile(self, zip_file, filename, sentence_size):
        cut_words = []
        labels = []
        if not os.path.exists(self.save_path):
            os.makedirs(self.save_path)
        with open(os.path.join(self.save_path,'split_words.txt'), 'w') as f:
            with zipfile.ZipFile(zip_file, 'r') as zip_file:
                data_file = zip_file.open(filename)
                lines = data_file.readlines()
                words_info = {}
                for line in lines[1:]:
                    try:
                        line = line.decode('utf8', 'ignore')
                        infos = line.split('||', 3)
                        sentence = infos[3]
                        label = infos[2]
                        if sentence is None:
                            continue
                        sentence = sentence.strip()
                        # label = convert_label(label)
                        if sentence == '' or label is None:
                            continue
                        if self.cut_tool == 'jieba':
                            words = pseg.cut(sentence)
                            words = [word.word.encode('utf8') for word in words if word.flag != 'x']
                        # elif self.cut_tool == 'thulac':
                        #     word_cut_thulac = thulac.thulac()
                        #     words = word_cut_thulac.cut(sentence)
                        #     words = [word[0].encode('utf8') for word in words if word[1] not in ('w', ) and word != ' ']
                        else:
                            print('cut tool not support')
                            raise Exception
                        cut_words.append(words)
                        labels.append(label)
                        word_len = len(words)
                        if word_len in words_info:
                            words_info[word_len] += 1
                        else:
                            words_info[word_len] = 1
                        f.write('{0}||{1}||{2}\r\n'.format(infos[0], label, ','.join(words)))
                    except:
                        traceback.print_exc()
                        print('error=========================')

                del lines
        np.save(os.path.join(self.save_path, 'label.npy'), np.array(labels))
        data_size = len(cut_words)
        label_size = len(labels)
        if data_size != label_size:
            print('data_size != label_size')
        del labels
        gc.collect()
        print('shape: ', data_size, sentence_size, self.model.model.vector_size)
        for i in range(data_size):
            index = i % 30000
            if index == 0:
                fileindex = i / 30000
                if fileindex != 0:
                    np.save(os.path.join(self.save_path, 'vec_%d.npy' % fileindex), results)
                if i + 30000 < data_size:
                    results = np.zeros(shape=(30000, sentence_size, self.model.model.vector_size))
                else:
                    results = np.zeros(shape=(data_size-i, sentence_size, self.model.model.vector_size))
            counter = 0
            for j in range(len(cut_words[i])):
                word = cut_words[i][j].encode('utf8').decode('utf8')
                if word in self.model.model:
                    results[index][counter] = self.model.model[word]
                    counter += 1
                if counter == sentence_size:
                    break
        np.save(os.path.join(self.save_path, 'vec_%d.npy' % (int(data_size/30000) + 1)), results)
        print(words_info)

    def to_vector_from_split_file(self, split_file, sentence_size=60, sample=100):
        label_1000_convert = {label.encode('utf8').decode('utf8'): num for label, num in label_1000.items()}
        label_skip_step = {label.encode('utf8').decode('utf8'): int(num/sample) for label, num in label_1000_convert.items()}
        label_step = {label.encode('utf8').decode('utf8'): 1 for label, num in label_1000_convert.items()}
        label_counter = {label.encode('utf8').decode('utf8'): 1 for label, num in label_1000_convert.items()}
        label_index = list(label_1000_convert.keys())
        label_index = [label.encode('utf8').decode('utf8') for label in label_index]
        labels = []
        word_vec = np.zeros(shape=(len(label_1000_convert)*sample, sentence_size, self.model.model.vector_size))
        print(word_vec.shape)
        global_counter = 0
        all_label = {}
        with open(split_file, 'rb') as f:
            lines = f.readlines()
            is_first = True
            index = 0
            for line in lines[1:]:
                try:
                    global_counter += 1
                    line = line.decode('utf8', 'ignore')
                    label, sentence = line.split('||', 2)[1:3]
                    if label in all_label:
                        all_label[label] += 1
                    else:
                        all_label[label] = 1
                    # if label == '盗窃汽车案':
                    #     print(label)
                    if sentence is None:
                        continue
                    sentence = sentence.strip()
                    if sentence == '':
                        continue
                    words = sentence.split(',')
                    label = label.encode('utf8').decode('utf8')
                    # if is_first:
                    #     print(label)
                    #     print(label in label_1000_convert)
                    #     for key, value in label_1000_convert.items():
                    #         print(key, value)
                    #     return
                    if label not in label_1000_convert:
                        continue
                    if label_step[label] == label_skip_step[label] and label_counter[label] <= sample:
                        counter = 0
                        for i in range(len(words)):
                            word = words[i].encode('utf8').decode('utf8')
                            if word in self.model.model:
                                if is_first:
                                    print(word)
                                word_vec[index][counter] = self.model.model[word]
                                counter += 1
                                if counter == sentence_size:
                                    break
                        label_step[label] = 1
                        labels.append(label_index.index(label))
                        label_counter[label] += 1
                        index += 1
                        is_first = False
                    else:
                        label_step[label] += 1
                except:
                    traceback.print_exc()
                    print('error=========================')
                    print(line)
                    return
        np.save(os.path.join(self.save_path, 'vec.npy'), word_vec)
        np.save(os.path.join(self.save_path, 'label.npy'), np_utils.to_categorical(labels, len(label_1000_convert)))

    def label_info(self, zip_file, filename):
        labels = {}
        with zipfile.ZipFile(zip_file, 'r') as zip_file:
            data_file = zip_file.open(filename)
            lines = data_file.readlines()
            for line in lines[1:]:
                try:
                    line = line.decode('utf8', 'ignore')
                    infos = line.split('||', 3)
                    label = infos[2]
                    if label in labels:
                        labels[label] += 1
                    else:
                        labels[label] = 1
                except:
                    print('error')
        for key in labels.keys():
            if labels[key] > 1000:
                print("\'%s\' : %d," % (key, labels[key]))

if __name__ == '__main__':
    # filename, model_name = sys.argv[1:3]
    filename, model_name = 'E:\intern\\a+tj\data\\aj\\split_words.txt', 'aj10'
    model = WordModel(model_name, 100, 10, 5, 30, 'skip-gram')
    model.load_model()
    wordVec = WordToVector(model, model.save_path)
    wordVec.to_vector_from_split_file(filename)
    # wordVec.label_info(zip_file, filename)