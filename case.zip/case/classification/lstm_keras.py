#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
sys.path.append('../../../Chu')
from keras import layers, models
from keras.optimizers import Adam, SGD
import numpy as np


def get_model(shape, class_num):
    model = models.Sequential()
    model.add(layers.Masking(mask_value=0, input_shape=(shape[0], shape[1])))
    model.add(layers.LSTM(64, input_shape=(shape[0], shape[1])))
    model.add(layers.Dense(class_num, activation='softmax'))
    # optimizer = Adam(1e-3)
    optimizer = SGD(lr=1e-3, decay=1e-6, momentum=0.9, nesterov=True)
    model.compile(optimizer, 'categorical_crossentropy', metrics=['accuracy'])
    return model

train_ratio = 0.7
x = np.load('../model/aj10/word2vec/vec.npy')
y = np.load('../model/aj10/word2vec/label.npy')
sample_size = y.shape[0]
x = x[:sample_size, :, :]
index = np.arange(sample_size)
np.random.shuffle(index)
x = x[index]
y = y[index]
print(x.shape)
print(y.shape)
train_len = int(sample_size*train_ratio)
train_x = x[:train_len]
train_y = y[:train_len]
test_x = x[train_len:]
test_y = y[train_len:]
print(train_x.shape)
row_num, col_num = train_x.shape[1:3]
class_num = train_y.shape[1]
type = get_model((row_num, col_num), class_num)
type.summary()
# train_x = np.resize(train_x, (train_x.shape[0], row_num, col_num))
# test_x = np.resize(test_x, (test_x.shape[0], row_num, col_num))
type.fit(train_x, train_y, batch_size=16, epochs=500, validation_data=[test_x, test_y], verbose=1)
scores = type.evaluate(test_x, test_y, verbose=1)
print("Model Accuracy: %.2f%%" % (scores[1]*100))